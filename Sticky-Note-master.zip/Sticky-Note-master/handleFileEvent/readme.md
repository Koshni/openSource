Demo to handle Cancel and Submit events of Browse File dialog box.

Reference - http://stackoverflow.com/questions/4628544/how-to-detect-when-cancel-is-clicked-on-file-input
