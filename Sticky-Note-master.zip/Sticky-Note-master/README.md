# Sticky-Note
Sticky Note for Mozilla Firefox. 
